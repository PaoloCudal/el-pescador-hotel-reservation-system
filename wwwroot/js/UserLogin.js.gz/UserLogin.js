﻿document.addEventListener("DOMContentLoaded", () => {

    /* ---------- LOGIN ELEMENTS ---------- */
    const emailInput = document.getElementById("email");
    const passwordInput = document.getElementById("password");
    const emailErrorSpan = document.getElementById("email-error");
    const passwordErrorSpan = document.getElementById("password-error");
    const loginButton = document.getElementById("login-button");

    let emailValid = false;
    let passwordValid = false;

    /* ---------- PASSWORD TOGGLE ---------- */
    window.togglePass = function (el) {
        const input = el.closest('.input-wrapper').querySelector('input');
        const icon = el.querySelector('.material-icons');
        if (input.type === "password") {
            input.type = "text";
            icon.textContent = "visibility_off";
        } else {
            input.type = "password";
            icon.textContent = "visibility";
        }
    };

    /* ---------- LIVE EMAIL VALIDATION ---------- */
    emailInput.addEventListener("input", () => {
        clearTimeout(emailInput.emailTimeout);
        emailInput.emailTimeout = setTimeout(async () => {

            const email = emailInput.value.trim();
            if (!email) {
                emailErrorSpan.textContent = "";
                emailInput.classList.remove("input-validation-error");
                emailValid = false;
                return;
            }

            try {
                const res = await fetch(`/api/auth/check-email?email=${encodeURIComponent(email)}`);
                const data = await res.json();

                if (!data.exists) {
                    emailErrorSpan.textContent = "Email not found";
                    emailInput.classList.add("input-validation-error");
                    emailValid = false;
                } else {
                    emailErrorSpan.textContent = "";
                    emailInput.classList.remove("input-validation-error");
                    emailValid = true;
                }
            } catch {
                emailErrorSpan.textContent = "Server error";
                emailValid = false;
            }

        }, 300);
    });

    /* ---------- LIVE PASSWORD VALIDATION ---------- */
    passwordInput.addEventListener("input", () => {
        clearTimeout(passwordInput.passwordTimeout);
        passwordInput.passwordTimeout = setTimeout(async () => {

            const email = emailInput.value.trim();
            const password = passwordInput.value.trim();

            if (!email || !password) {
                passwordErrorSpan.textContent = "";
                passwordInput.classList.remove("input-validation-error");
                passwordValid = false;
                return;
            }

            try {
                const res = await fetch('/api/auth/check-password', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ Email: email, Password: password })
                });

                const data = await res.json();

                if (!data.valid) {
                    passwordErrorSpan.textContent = "Incorrect password";
                    passwordInput.classList.add("input-validation-error");
                    passwordValid = false;
                } else {
                    passwordErrorSpan.textContent = "";
                    passwordInput.classList.remove("input-validation-error");
                    passwordValid = true;
                }
            } catch {
                passwordErrorSpan.textContent = "Server error";
                passwordValid = false;
            }

        }, 300);
    });

    /* ---------- TOAST NOTIFICATION ---------- */
    function showToast(message, type = "success", duration = 3000) {
        const container = document.getElementById("toast-container");
        if (!container) return;

        const toast = document.createElement("div");
        toast.classList.add("toast", type === "error" ? "toast-error" : "toast-success");
        toast.innerHTML = `${message} <button class="toast-close">&times;</button>`;

        container.appendChild(toast);

        // Show immediately
        toast.classList.add("show");

        // Close manually
        toast.querySelector(".toast-close").onclick = () => toast.remove();

        // Auto remove
        setTimeout(() => {
            toast.classList.remove("show");
            setTimeout(() => toast.remove(), 300);
        }, duration);
    }


    /* ---------- LOGIN BUTTON ---------- */
    loginButton.addEventListener("click", () => {
        if (!emailValid || !passwordValid) {
            showToast("Please fix all errors before logging in.", "error");
            return;
        }
        loginUser();
    });

    async function loginUser() {
        try {
            const res = await fetch('/api/auth/login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    email: emailInput.value.trim(),
                    password: passwordInput.value.trim()
                })
            });

            const data = await res.json();

            if (!res.ok) {
                showToast(data.message || "Login failed!", "error");
                return;
            }

            localStorage.setItem("jwtToken", data.token);
            showToast("Login successful!", "success");

            setTimeout(() => window.location.href = "/HomeIndex", 900);

        } catch {
            showToast("Server error. Please try again.", "error");
        }
    }

    /* ---------- ENTER KEY ---------- */
    [emailInput, passwordInput].forEach((el, index, arr) => {
        el.addEventListener("keydown", (e) => {
            if (e.key === "Enter") {
                e.preventDefault();
                if (index < arr.length - 1) arr[index + 1].focus();
                else if (emailValid && passwordValid) loginUser();
            }
        });
    });

    /* ---------- FORGOT PASSWORD MODAL ---------- */
    const modal = document.getElementById("forgotPasswordModal");
    const forgotEmailInput = document.getElementById("forgotEmail");
    const forgotEmailError = document.getElementById("forgot-email-error");
    const forgotBtn = document.getElementById("forgotPasswordBtn");

    window.openForgotPasswordModal = () => {
        modal.style.display = "flex";
        forgotEmailInput.value = "";
        forgotEmailError.textContent = "";
        forgotEmailInput.classList.remove("input-validation-error");
    };

    window.closeForgotPasswordModal = () => {
        modal.style.display = "none";
    };

    window.addEventListener("click", (e) => {
        if (e.target === modal) modal.style.display = "none";
    });

    /* ---------- LIVE VALIDATION (Forgot Password) ---------- */
    forgotEmailInput.addEventListener("input", () => {
        clearTimeout(forgotEmailInput.emailTimeout);
        forgotEmailInput.emailTimeout = setTimeout(async () => {
            const email = forgotEmailInput.value.trim();

            if (!email) {
                forgotEmailError.textContent = "";
                forgotEmailInput.classList.remove("input-validation-error");
                return;
            }

            try {
                const res = await fetch(`/api/auth/check-email?email=${encodeURIComponent(email)}`);
                const data = await res.json();

                if (!data.exists) {
                    forgotEmailError.textContent = "Email not found";
                    forgotEmailInput.classList.add("input-validation-error");
                } else {
                    forgotEmailError.textContent = "";
                    forgotEmailInput.classList.remove("input-validation-error");
                }

            } catch {
                forgotEmailError.textContent = "Server error";
            }

        }, 300);
    });

    /* ---------- SEND RESET LINK ---------- */
    forgotBtn.addEventListener("click", async () => {
        const email = forgotEmailInput.value.trim();

        if (!email) {
            showToast("Please enter your email.", "error");
            return;
        }
        // Start pulse/fade animation
        forgotBtn.disabled = true;
        try {
            const res = await fetch('/api/auth/forgot-password', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email })
            });

            const data = await res.json();
            const toastDuration = 3000;

            if (res.ok) {
                showToast("Reset link sent!", "success", toastDuration);

                // Wait until toast ends before closing modal
                setTimeout(() => {
                    closeForgotPasswordModal();
                    forgotBtn.disabled = false;
                    forgotBtn.textContent = "Send Reset Link";
                    forgotBtn.classList.remove("loading");
                }, toastDuration);
            } else {
                showToast(data.message || "Error sending reset link.", "error");
                forgotBtn.disabled = false;
                forgotBtn.textContent = "Send Reset Link";
                forgotBtn.classList.remove("loading");
            }

        } catch {
            showToast("Server error. Try again later.", "error");
            forgotBtn.disabled = false;
            forgotBtn.textContent = "Send Reset Link";
            forgotBtn.classList.remove("loading");
        }
    });




});
