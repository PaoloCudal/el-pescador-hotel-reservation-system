﻿document.addEventListener("DOMContentLoaded", () => {
    const form = document.getElementById("loginForm");
    if (!form) return;

    form.addEventListener("submit", (e) => {
        const firstError = form.querySelector(".input-validation-error");
        if (firstError) {
            e.preventDefault();
            firstError.focus();
        }
    });

    const emailInput = document.querySelector("input[name='Email']");
    const passwordInput = document.querySelector("input[name='Password']");

    //Email Live Validation
    emailInput.addEventListener("input", () => {
        clearTimeout(emailInput.emailTimeout);
        emailInput.emailTimeout = setTimeout(() => {
            const errorSpan = document.querySelector("[data-valmsg-for='Email']");

            if (!emailInput.value.trim()) {
                errorSpan.textContent = "";
                emailInput.classList.remove("input-validation-error");
                return;
            }

            fetch(`?handler=CheckEmail&email=${encodeURIComponent(emailInput.value)}`)
                .then(res => res.json())
                .then(data => {
                    if (!data.exists) {
                        errorSpan.textContent = "Email not found";
                        emailInput.classList.add("input-validation-error");
                    } else {
                        errorSpan.textContent = "";
                        emailInput.classList.remove("input-validation-error");
                    }
                })
        }, 300);
    });

    //Live Password Validation
    passwordInput.addEventListener("input", () => {
        const email = emailInput.value;
        const password = passwordInput.value;
        if (!email) return;

        clearTimeout(passwordInput.passwordTimeout);
        passwordInput.passwordTimeout = setTimeout(() => {
            const errorSpan = document.querySelector("[data-valmsg-for='Password']");

            if (!passwordInput.value.trim()) {
                errorSpan.textContent = "";
                passwordInput.classList.remove("input-validation-error");
                return;
            }

            fetch(`?handler=CheckPassword&email=${encodeURIComponent(email)}&password=${encodeURIComponent(password)}`)
                .then(res => res.json())
                .then(data => {
                    if (!data.correct) {
                        errorSpan.textContent = "Incorrect Password";
                        passwordInput.classList.add("input-validation-error");
                    } else {
                        errorSpan.textContent = "";
                        passwordInput.classList.remove("input-validation-error");
                    }
                });
        }, 300);
    });

    //Toggle eye function
    function toglePass(el) {
        const input = el.closest('.password-wrap').querySelector('input');
        const icon = el.querySelector('.material-icons');
        const isPassword = input.type === "password";

        input.type = isPassword ? "visibility_off" : "visibility";
        icon.textContent = isPassword ? "visibility_off" : "visibility";

        input.focus();
    }
    window.toglePass = toglePass;

    const inputs = form.querySelectorAll("input[type='email'], input[type='password']");
    inputs.forEach((input, index) => {
        input.addEventListener("keydown", (e) => {
            if (e.key === "Enter") {
                e.preventDefault();
                if (index < inputs.length - 1) {
                    inputs[index + 1].focus();
                } else {
                    form.requestSubmit();
                }
            }
        });
    });
});